/** Automatically generated file. DO NOT MODIFY */
package org.sec.NanoomMungo.Activity;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}