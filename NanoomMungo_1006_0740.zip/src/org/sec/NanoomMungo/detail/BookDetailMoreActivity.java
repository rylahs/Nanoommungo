package org.sec.NanoomMungo.detail;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.ImageDownloader;
import org.sec.NanoomMungo.Utils.ImageDownloader.Mode;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.parsing.ServerManager;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

public class BookDetailMoreActivity extends Activity {
	private TextView bookName, author, publisher, category, grade, contents;
			//myRatingText;
	private ImageView okButton, BookImage;
	//private RatingBar myRating;
	private ImageDownloader downloader;

	int num;
	String name;
	String img_url;
	String Head = "";
	String content_ ="";
	String genre_ = "";
	String author_ = "";
	
	int album_num;

	// ���α׷��� �ڵ鷯
	private ProgressDialog m_ProgressDialog = null;
	private static final int WRITING = 1;
	private Handler handler = new Handler();
	public final int PROGRESS = 1;
	// ���α׷��� �ڵ鷯

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_book_detail_more);
		getInformation();

		if (Head.length() != 0) {
			TextView v = (TextView) this.findViewById(R.id.head);
			v.setText(Head);
		}

		downloader = new ImageDownloader();
		downloader.setMode(Mode.CORRECT);
		BookImage = (ImageView) findViewById(R.id.BookImage);
		downloader.download(img_url, BookImage);

		//String contents = "���� ���� �󱼿� ���� ���� ������ ȫ���� �� �� ����.\n�׿��� �������� ������ ���ܻ�� �Ź���\n\n\"��, �𸨴ϱ�?\"\n����ü �׸� ����,��� ������ ���ΰ�!\n�ѹ� ���� ���� ���ϴ� �λ��ε� �� ���� �׸� ������� ���Ѵ� ���ΰ�!\n\"Ȥ��......�����, ������ ����ϰ� ��Ű���?\"�� ������ ���� ��ġ \'���� �Ƽ���?\'��� ������ ���� ����ó�� ����.\n\"�׷��ϱ� ������ ����ϰ� ��� �� �ƴϳİ���.";
		setContents(name, author_, genre_, content_);

		okButton = (ImageView) findViewById(R.id.completeButton);
		okButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				okButton.setSelected(true);
				Intent i = new Intent(BookDetailMoreActivity.this,
						BookDetailActivity.class);
				
				//Log.v("TEST", "å���� = " + name);
				//Log.v("TEST", "��ũ = " + img_url);
				
				i.putExtra("name", name);
				i.putExtra("url", img_url);
				startActivity(i);
			}

		});

		/*myRating = (RatingBar) findViewById(R.id.myRating);
		myRatingText = (TextView) findViewById(R.id.myRatingText);

		float ratingPoint = (float) 3.5;
		myRating.setRating(ratingPoint);
		myRatingText.setText("" + ratingPoint);*/
	}

	public void setContents(String title, String author,
			String category, String contents) {
		this.bookName = (TextView) findViewById(R.id.bookName);
		bookName.setText(title);
		
		this.author = (TextView) findViewById(R.id.author);
		this.author.setText(author);
		
		this.category = (TextView) findViewById(R.id.category);
		this.category.setText(category);
		
		this.contents = (TextView) findViewById(R.id.content);
		this.contents.setText(contents);
	}

	private void getInformation() {
		Intent i = getIntent();
		name = i.getStringExtra("name");
		img_url = i.getStringExtra("url");
		num = i.getIntExtra("num", 0);
		album_num = i.getIntExtra("album_num", 0);
		
		//Log.v("TEST", "å��ȣ= " + num);
		//Log.v("TEST", "å�̸�= " + name);
		//Log.v("TEST", "�ٹ���ȣ= " + album_num);
				
		try {
			Thread thread = new Thread(null, Run_getInfo);
			thread.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (i.getStringExtra("Head") != null) {
			Head = i.getStringExtra("Head");
		}
	}
	
	private Runnable Run_getInfo = new Runnable() {
		public void run() {
			getParsingInfo(num);
			handler.post(updateResults);
//			m_ProgressDialog.dismiss();

		}
	};
	
	public void getParsingInfo(int num) {
		// parsing 
		// Parsing - ����� ���� �ݿ� �� å 
		// �ŷڵ�
		String url = Utils.http + "db/show_bookinfo.php";
		ServerManager serverManager = new ServerManager();
		StringBuffer sb = new StringBuffer();
		sb.append("no=" + num).append("&");
		sb.append("album_no=" + album_num);
		
		StringBuffer tmp = serverManager.whereJsonData(url, sb);
		
		try {
			JSONObject jObject = new JSONObject(tmp.toString());
			JSONArray jsonObject = jObject.getJSONArray("regulatory");
						
			if (jsonObject.length() == 0) {
				// ����� ��
			} else {
				for(int i=0; i<jsonObject.length(); i++)
				{
					jObject = jsonObject.getJSONObject(i);
					content_ = jObject.getString("content");
					author_ = jObject.getString("author");
					//genre_ = jObject.getString("genre");
				}				
			}
			
			url = Utils.http + "db/show_genre.php";
			serverManager = new ServerManager();
			sb = new StringBuffer();
			sb.append("album_no=" + album_num);
			tmp = serverManager.whereJsonData(url, sb);

			try {
				jObject = new JSONObject(tmp.toString());
				jsonObject = jObject.getJSONArray("regulatory");
				jObject = jsonObject.getJSONObject(0); 
				
				if (jsonObject.length() == 0) {
					// ����� ��
				} else {
					for(int i=0; i<jsonObject.length(); i++)
					{
						genre_ = jObject.getString("genre");
						//Log.v("TEST", "�ٹ��帣 = " + genre_);
					}				
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	private Runnable updateResults = new Runnable() {
		public void run() {
			setContents(name, author_, genre_, content_);
		}
	};
}
