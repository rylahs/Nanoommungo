package org.sec.NanoomMungo.detail;

public class likeDetailRowData {
	private String name;
	private String addr;
	private String user_id;
	private int album_number;
	private String distance;
 
	public likeDetailRowData(String name, String addr, String distance, String user_id, int album_number) {
		this.name = name;
		this.addr = addr;
		this.distance = distance;
		this.user_id = user_id;
		this.album_number = album_number;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}
	
	public String getId() {
		return user_id;
	}
	
	public int getAlbumNum() {
		return album_number;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}
}
