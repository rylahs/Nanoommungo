package org.sec.NanoomMungo.detail;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sec.NanoomMungo.Activity.App;
import org.sec.NanoomMungo.Activity.BooksRowData;
import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Activity.TabMainActivity;
import org.sec.NanoomMungo.Adapter.DetailListViewAdapter;
import org.sec.NanoomMungo.Login.LoginActivity;
import org.sec.NanoomMungo.Utils.ImageDownloader;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.Utils.ImageDownloader.Mode;
import org.sec.NanoomMungo.parsing.ServerManager;
import org.sec.NanoomMungo.tab2.AlbumDetailActivity;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class BookDetailActivity extends Activity implements OnScrollListener, LocationListener{

	String name;
	String img_url;
	ImageDownloader downloader;
	Context mContext;
	ListView list;
	//RatingBar rating;
		
	// ��ũ�� �ε�
    private LayoutInflater mInflater;
    private boolean mLockListView;
    
    DetailListViewAdapter bindingData;
    ArrayList<likeDetailRowData> Datalist;
    
    // ���α׷���
    public final int PROGRESS = 1;
    private ProgressDialog m_ProgressDialog = null;
	private Handler handler = new Handler();
	
	// ������ ����Ʈ ����
	private int json_cnt = 0;
	private int json_count = 0;
	private String user_name[];
	private String user_location[];
	private String user_distance[];
	private String user_id[];
	private int user_album_num[];
		    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
			
		setContentView(R.layout.activity_book_detail);		
		mContext = this;
				
		getInformation();
		setInformation();
		
		mLockListView = false;

		list = (ListView) findViewById(R.id.list);
		
		// Ǫ�͸� ���. setAdapter ������ �ؾ���.
        mInflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        list.addFooterView(mInflater.inflate(R.layout.listview_footer, null));

        // ��ũ�� ������ ���
        list.setOnScrollListener(this);
        
		Datalist = new ArrayList<likeDetailRowData>();
		
		//������ ����Ʈ ������
		Thread thread = new Thread(null, Sending_question);
		thread.start();
		showDialog(PROGRESS);
		//addItems();
				
		bindingData = new DetailListViewAdapter(this,
				R.layout.like_row, Datalist);
        
		list.setAdapter(bindingData);
		
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int Listposition, long id) {
				// TODO Auto-generated method stub
				likeDetailRowData mData = Datalist.get(Listposition);
				
				Log.v("TEST", "==============================" );
				Log.v("TEST", "å���� = " + name);
				Log.v("TEST", "��ũ = " + img_url);				
				Log.v("TEST", "�̸� = " + mData.getName() );
				Log.v("TEST", "�Ÿ� = " + mData.getDistance() );
				Log.v("TEST", "�ּ� = " + mData.getAddr() );
				Log.v("TEST", "���̵� = " + mData.getId() );
				Log.v("TEST", "�ٹ���ȣ = " + mData.getAlbumNum() );
				Log.v("TEST", "==============================" );
				Intent intent = new Intent(BookDetailActivity.this, AlbumDetailActivity.class);
				intent.putExtra("no", mData.getAlbumNum());
				intent.putExtra("title", mData.getName());
				intent.putExtra("distance", mData.getDistance());
				startActivity(intent);
			}
		});
	}
	
	private Runnable Sending_question = new Runnable() {
		public void run() {
			Get_UserList();
			handler.post(updateResults);
		}
	};
	
	private Runnable updateResults = new Runnable() {
		public void run() { 
			m_ProgressDialog.dismiss(); 
			afterProceeding();
		}
	};
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case (PROGRESS):
			m_ProgressDialog = new ProgressDialog(this);
			m_ProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			m_ProgressDialog.setMessage("loading..");
			return m_ProgressDialog;
		}
		return null;
	}
	
	private void afterProceeding(){
		// �����ϴ� �κ�
		//addItems();
		Log.v("TEST", "================");
		Log.v("TEST", "���� �� = " + json_cnt);		
		json_count = 0;
		Log.v("TEST", "================");
		for(int i=0; i<json_cnt; i++){
			Log.v("TEST", "================");
			Log.v("TEST", "�ٹ���ȣ = " + user_album_num[i]);
			Log.v("TEST", "�Ÿ� = " + user_distance[i] );
			Log.v("TEST", "�̸� = " + user_name[i] );
			Log.v("TEST", "�ּ� = " + user_location[i] );
			Log.v("TEST", "���̵� = " + user_id[i] );
		}
		Log.v("TEST", "================");
		
	}
	
	private void Get_UserList() {
		// �����(������) ���� �޾ƿ���
		Log.v("TEST", "================");
		Log.v("TEST", "å�̸�= " + name);

		ServerManager serverManager;
		App app = (App) getApplicationContext();
		serverManager = app.getServerManager();

		String url = Utils.http + "db/search_user.php";
		StringBuffer sb = new StringBuffer();
		sb.append("where=" + name);
		StringBuffer tmp = serverManager.whereJsonData(url, sb);

		try {
			JSONObject jObject = new JSONObject(tmp.toString());
			JSONArray jsonObject = jObject.getJSONArray("regulatory");
			json_cnt = jsonObject.length();
			
			user_name = new String[json_cnt];
			user_location = new String[json_cnt];
			user_distance = new String[json_cnt];
			user_id = new String[json_cnt];
			user_album_num = new int[json_cnt];
					
			url = Utils.http + "db/search_user2.php";
			
			for (int i = 0; i < json_cnt; i++) {
				JSONObject jtmp = jsonObject.getJSONObject(i);
				
				user_album_num[i] = jtmp.getInt("album_no");
				user_distance[i] = GetDistance(Double.parseDouble(jtmp.getString("lat")), Double.parseDouble(jtmp.getString("lon")));
				
				sb = new StringBuffer();
				sb.append("where=" + user_album_num[i]);
				tmp = serverManager.whereJsonData(url, sb);

				try {
					JSONObject jObject2 = new JSONObject(tmp.toString());
					JSONArray jsonObject2 = jObject2.getJSONArray("regulatory");
					
					for (int j = 0; j < jsonObject2.length(); j++) {
						JSONObject jtmp2 = jsonObject2.getJSONObject(j);
						user_id[i] = jtmp2.getString("user_id") ;
						user_location[i] = jtmp2.getString("area_no") ;
						user_name[i] = jtmp2.getString("name") ;
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	public String GetDistance(double la, double lo) { // �Ÿ� ����ϱ�

		if(Utils.myLocation != null) {

			Location locateSeoul = new Location("Seoul");
			locateSeoul.setLatitude(la);
			locateSeoul.setLongitude(lo);
			int distance = (int)Utils.myLocation.distanceTo(locateSeoul) / 1000; // distanceTo �Լ��� ��ȯ�� m�� km�� ��ȯ

			if (distance == 0) { // 0km�� ��쿡�� m������ ȯ���ؼ� ���
				distance = (int)Utils.myLocation.distanceTo(locateSeoul);
				return String.valueOf(distance) + " m";
			}
			else {
				return String.valueOf(distance) + " km";
			}
			//RemoveGet(); // GPS���� �ߴ� �ڵ� ����, ���� ������ ����ؼ� ���Ƿ� ���͸� ��Ƹ��� ���ɼ� ����
		}
		return "�Ÿ���������";
	}
	
	public void RemoveGet() { // GPS ��� �Ӽ� ����
		Utils.locManager.removeUpdates(this);
	}
	
	public void onLocationChanged(Location location) {
		Log.d("location", "location changed");
		Utils.myLocation = location;
	}
	public void onProviderDisabled(String s) { 	}
	public void onProviderEnabled(String s) {	}
	public void onStatusChanged(String s, int i, Bundle bundle) {	}
	
	// ���� ������ �߰�
    private void addItems()
    {
        // �������� �߰��ϴ� ���� �ߺ� ��û�� �����ϱ� ���� ��.
        mLockListView = true;
        Runnable run = new Runnable()
        {
            @Override
            public void run()
            {
            	while(json_count < json_cnt)
            	{
            		//Datalist.add(new likeDetailRowData("Ȳ����", "����Ư���� ���α�", 120, "hdbaag", 142));
            		Datalist.add(new likeDetailRowData(user_name[json_count], user_location[json_count],
            				user_distance[json_count], user_id[json_count], user_album_num[json_count]));
            	
            		json_count++;
            	}
            	
                // ��� �����͸� �ε��Ͽ� �����Ͽ��ٸ� ����Ϳ� �˸���
                // ����Ʈ���� ���� ����
                bindingData.notifyDataSetChanged();
                mLockListView = false;
            }
        };
        // �ӵ��� �����̸� ����
        Handler handler = new Handler();
        handler.postDelayed(run, 1000);
    }
	
	@Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount)
    {
        // ���� ���� ó���� ���̴� ����ȣ�� �������� ����ȣ�� ���Ѱ���
        // ��ü�� ���ڿ� ���������� ���� �Ʒ��� ��ũ�� �Ǿ��ٰ� ����.
        int count = totalItemCount - visibleItemCount;
                
        if(firstVisibleItem >= count && totalItemCount != 0  && mLockListView == false)
        {
          if(check_userlist())	addItems();
        }  
    }
	
	private boolean check_userlist()
	{
		if(json_count < json_cnt)
		{
			Log.v("TEST", "�������� �����ϴ��� Ȯ�� �� Loading next items");
			 return true;
		}
		else
		{
			Log.v("TEST", "�������� ����");
			return false;
		}
	}
	
    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState)
    {
    }

	private void getInformation() {
		Intent i = getIntent();
		name = i.getStringExtra("name");
		img_url = i.getStringExtra("url");
	}

	private void setInformation() {
		downloader = new ImageDownloader();
		downloader.setMode(Mode.CORRECT);
		ImageView iv = (ImageView) findViewById(R.id.bookImg);
		
		TextView tv = (TextView) findViewById(R.id.txt);
		tv.setText(name);	
		
		try {
			downloader.download(img_url, iv);
		}
		catch (Exception e) {
		}
	}
	
	/*public class ViewHeader {
		public String Header;
		public String name;
		public int location;
		public boolean isGo;
	}*/
}
