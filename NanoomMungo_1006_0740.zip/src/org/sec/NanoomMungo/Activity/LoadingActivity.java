package org.sec.NanoomMungo.Activity;

import java.io.IOException;
import java.util.List;

import org.sec.NanoomMungo.Login.LoginActivity;
import org.sec.NanoomMungo.Utils.Utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class LoadingActivity extends Activity implements LocationListener {

	//GPS
	StringBuffer juso;
	Geocoder geoCoder; // 주소를 가져오기 위한 GeoDocer
	// 서울역 좌표로 Dummy 이 값을 사용자 아이디 파싱해서 받아야됨
	// la : 위도 , lo : 경도
	//double la = 37.554531; 
	//double lo = 126.97066300000006;
	double la = 36.7637515;  
	double lo = 127.2819829;
	int distance = 0; // 사용자간 거리
	String locationProvider = ""; // 기지국에서 받을지, GPS에서 받을지 설정하는 부분
	/** Called when the activity is first created. */	
	
	public final int PROGRESS = 1;
	private ProgressDialog m_ProgressDialog = null;
	private Handler handler = new Handler();
		
	public static final Handler postHandler = new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState); 
		setContentView(R.layout.activity_main);

		//Thread thread = new Thread(null, Sending_question);
		//thread.start();
		//showDialog(PROGRESS);
		
		Handler handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				overridePendingTransition(R.layout.fadein, R.layout.fadeout);
				if (Utils.isNetworkConn(LoadingActivity.this)) {
					
					Intent i = new Intent(LoadingActivity.this,
							LoginActivity.class); 					
					startActivity(i);
					finish();
					
				} else {
					AlertDialog.Builder builder = new AlertDialog.Builder(
							LoadingActivity.this)
							.setTitle("Internet Disconneted")
							.setMessage("Check your Internet State")
							.setCancelable(false)
							.setPositiveButton("OK",
									new DialogInterface.OnClickListener() {
										@Override
										public void onClick(
												DialogInterface dialog,
												int which) {
											finish();
										}
									});
					builder.show();
				}

			}
		};
		handler.sendEmptyMessageDelayed(0, 2000);
	}
	
	private Runnable Sending_question = new Runnable() {
		public void run() {
			Log.v("TEST", "====================1====================");
			GetLocations(); // 좌표 받아오기
			GetDistance();  // 거리 측정하기 , GPS 사용 종료
			handler.post(updateResults);
			Log.v("TEST", "====================2====================");
		}
	};
	
	private Runnable updateResults = new Runnable() {
		public void run() { 
			Intent i = new Intent(LoadingActivity.this,
					LoginActivity.class); 
			startActivity(i);
			finish();
			m_ProgressDialog.dismiss(); 
		}
	};
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case (PROGRESS):
			m_ProgressDialog = new ProgressDialog(this);
			m_ProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			m_ProgressDialog.setMessage("loading..");
			return m_ProgressDialog;
		}
		return null;
	}
	
	public void GetLocations() {
		// 텍스트뷰를 찾음
		juso = new StringBuffer();

		Log.v("TEST", "====================테스트1====================");
		do
		{
			Log.v("TEST", "====================테스트2====================");
			if (Utils.myLocation != null) { 
				Utils.latPoint = Utils.myLocation.getLatitude();
				Utils.lngPoint = Utils.myLocation.getLongitude();
				Log.v("TEST", "====================테스트3====================");
				try {
					// 위도,경도를 이용하여 현재 위치의 주소를 가져온다. 
					List<Address> addresses;
					addresses = geoCoder.getFromLocation(Utils.latPoint, Utils.lngPoint, 1);
					for(Address addr: addresses){
						int index = addr.getMaxAddressLineIndex();
						for(int i=0;i<=index;i++){
							juso.append(addr.getAddressLine(i));
							juso.append(" ");
						}
						juso.append("\n");
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}while(!gps_check());
		Log.v("TEST", "====================테스트4====================");
	}
	

	public void GetDistance() { // 거리 계산하기

		if(Utils.myLocation != null) {

			Location locateSeoul = new Location("Seoul");
			locateSeoul.setLatitude(la);
			locateSeoul.setLongitude(lo);
			distance = (int)Utils.myLocation.distanceTo(locateSeoul) / 1000; // distanceTo 함수의 반환은 m임 km로 변환

			if (distance == 0) { // 0km인 경우에는 m법으로 환산해서 계산
				distance = (int)Utils.myLocation.distanceTo(locateSeoul);
				Log.v("TEST" , "거리 = " + String.valueOf(distance) + " m");
			}
			else {
				Log.v("TEST" , "거리 = " + String.valueOf(distance) + " km");
			}
			RemoveGet(); // GPS수신 중단 코드 실행, 하지 않을시 계속해서 도므로 배터리 잡아먹을 가능성 높음
		}
	}
	
	@Override
	public void onBackPressed() {
	} 
	
	public boolean gps_check()
	{
		if(Utils.latPoint == 0.0)
		{
			//Log.v("TEST" , "GPS 실패");
			return false;
		}
		if(Utils.lngPoint == 0.0)
		{
			//Log.v("TEST" , "GPS 실패");
			return false;
		}
		if(String.valueOf(juso) == null)
		{
			//Log.v("TEST" , "GPS 실패");
			return false;
		}
		
		{
			Log.v("TEST" , "내 위도 = " + Utils.latPoint);
			Log.v("TEST" , "내 경도 = " + Utils.lngPoint);
			Utils.address_juso = String.valueOf(juso);
			Log.v("TEST" , "내 주소 = " + Utils.address_juso);
			return true;
		}
	}
	

	public void onLocationChanged(Location location) {
		Log.d("location", "location changed");
		Utils.myLocation = location;
	}
	
	public void onProviderDisabled(String s) { 	}
	public void onProviderEnabled(String s) {	}
	public void onStatusChanged(String s, int i, Bundle bundle) {	}
	
	
	public void RemoveGet() { // GPS 사용 속성 제거
		Utils.locManager.removeUpdates(this);
	}

}
