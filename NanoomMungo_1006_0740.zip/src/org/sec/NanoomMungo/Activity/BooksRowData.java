package org.sec.NanoomMungo.Activity;

public class BooksRowData {
	private String url;
	private String name;
	private String distance;
	
	private int num;
	private int album_num;

	public BooksRowData(String name, String url, String distance, int num, int album_num) {
		this.url = url;
		this.name = name;
		this.distance = distance;
		this.num = num;
		this.album_num = album_num;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getNum() {
		return num;
	}

	public int getAlbum_Num() {
		return album_num;
	}
}
