package org.sec.NanoomMungo.Activity;

import org.sec.NanoomMungo.parsing.ServerManager;

import android.app.Application;
import android.widget.Toast;

public class App extends Application {

	public Toast finishToast;
	public boolean isFinish;
	private ServerManager serverManager;
	private GCMManager gcmManager;

	@Override
	public void onCreate() {
		super.onCreate();

		gcmManager = new GCMManager(getApplicationContext());
		serverManager = new ServerManager();
		finishToast = Toast.makeText(getApplicationContext(),
				"\'�ڷΰ���\'�� �ѹ� �� ���� �����Ͻʽÿ�.", Toast.LENGTH_LONG);
		isFinish = false;
	}
	
	public GCMManager getGCMManager(){
		return gcmManager;
	}
	
	public ServerManager getServerManager(){
		return serverManager;
	}
}