package org.sec.NanoomMungo.Activity;

import org.sec.NanoomMungo.Dialog.DialogBox;
import org.sec.NanoomMungo.Dialog.SearchDialogBox;
import org.sec.NanoomMungo.Login.LoginActivity;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.board.AdjustActivity;
import org.sec.NanoomMungo.board.MessageStorageActivity;
import org.sec.NanoomMungo.board.Notice;
import org.sec.NanoomMungo.tab1.Tab1Activity;
import org.sec.NanoomMungo.tab2.Tab2Activity;
import org.sec.NanoomMungo.tab3.Tab3Activity;

import android.app.TabActivity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;

import com.navdrawer.SimpleSideDrawer;

public class TabMainActivity extends TabActivity implements OnTabChangeListener {
	private SimpleSideDrawer mNav;
	private DialogBox dialogs;

	private ImageView Menu_search;
	private ImageView Menu_Board, exit;
	private TextView notice, adjust, logout, messageStorage;
	private TabWidget widget;
	private TabHost host;
	private Context mContext;
	private SearchDialogBox dialog;  

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tab_main);
		
		Intent i = new Intent("org.sec.NanoomMungo.Activity.GCMIntentService");
		stopService(i);
		
		App app = (App) getApplicationContext();
		GCMManager gcmManager = app.getGCMManager();
		gcmManager.registerGcm(); 
		
		mNav = new SimpleSideDrawer(this);
		mNav.setRightBehindContentView(R.layout.activity_right);
		mContext = this;

		Menu_search = (ImageView) findViewById(R.id.search);
		Menu_Board = (ImageView) findViewById(R.id.board);

		Menu_search.setOnClickListener(MenuListener);
		Menu_Board.setOnClickListener(MenuListener);

		host = getTabHost();
		widget = host.getTabWidget();

		TabHost.TabSpec spec;
		spec = host.newTabSpec("Main");
		spec.setContent(new Intent(this, Tab1Activity.class));
		spec.setIndicator("��õå", getIcon(android.R.drawable.btn_star));
		host.addTab(spec);
		spec = host.newTabSpec("Second");
		spec.setContent(new Intent(this, Tab2Activity.class));
		spec.setIndicator("ī�װ���", getIcon(android.R.drawable.btn_star));
		host.addTab(spec);
		spec = host.newTabSpec("Third");
		spec.setContent(new Intent(this, Tab3Activity.class));
		spec.setIndicator("�� ����", getIcon(android.R.drawable.btn_star));
		host.addTab(spec);
		  
		// Tablayout
		notice = (TextView) mNav.getRightBehindView().findViewById(R.id.notice);
		messageStorage = (TextView) mNav.getRightBehindView().findViewById(R.id.message);
		adjust = (TextView) mNav.getRightBehindView().findViewById(R.id.adjust);
		logout = (TextView) mNav.getRightBehindView().findViewById(R.id.logout);
		exit = (ImageView) mNav.getRightBehindView().findViewById(R.id.exit); 
		TextView id = (TextView) mNav.getRightBehindView().findViewById(R.id.id);
		TextView email = (TextView) mNav.getRightBehindView().findViewById(R.id.email);
		id.setText(Utils.user_name);
		email.setText(Utils.user_id);

		notice.setOnClickListener(setButtonListener);
		adjust.setOnClickListener(setButtonListener);
		logout.setOnClickListener(setButtonListener);
		exit.setOnClickListener(setButtonListener);
		messageStorage.setOnClickListener(setButtonListener);
		
		host.setOnTabChangedListener(this); 
	}

	private View.OnClickListener setButtonListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			if(mNav.isClosed())
				return;
			
			switch (v.getId()) {
			case R.id.notice:
				notice.setSelected(true);
				startActivity(new Intent(TabMainActivity.this, Notice.class));
				break;
			case R.id.message:
				messageStorage.setSelected(true);
				startActivity(new Intent(TabMainActivity.this, MessageStorageActivity.class));
				break;
			case R.id.adjust:
				adjust.setSelected(true);
				startActivity(new Intent(TabMainActivity.this,
						AdjustActivity.class));
				break;
			case R.id.logout:
				logout.setSelected(true);
				dialogs = new DialogBox(mContext);
				dialogs.setTitle("�α׾ƿ�");
				dialogs.setMessage("�α׾ƿ� �Ͻðڽ��ϱ�?");
				dialogs.Show();
				dialogs.getPositiveButton().setOnClickListener(
						new OnClickListener() {

							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								Logout();
								dialogs.Close();
							}

						});

				break;
			case R.id.exit:
				dialogs = new DialogBox(mContext);
				dialogs.setTitle("����");
				dialogs.setMessage("�����Ͻðڽ��ϱ�?");
				dialogs.Show();
				dialogs.getPositiveButton().setOnClickListener(
						new OnClickListener() {

							@Override
							public void onClick(View v) {
								// TODO Auto-generated method stub
								System.exit(0);
							}

						});
				break;
			}
		}  
	};
	
	private void Logout(){
		// sharepre... remove
		setPreferenceID_PWD(null, null);
		SetPreferenceAuto(false);
		this.finish();
		startActivity(new Intent(this, LoginActivity.class));
	}
	
	public void setPreferenceID_PWD(String _id, String _pwd) {
		SharedPreferences pref = getSharedPreferences("LoginInfo", 0);
		SharedPreferences.Editor edit = pref.edit();

		edit.putString("id", _id);
		edit.putString("pwd", _pwd);
		edit.commit();
	} 
	
	public void SetPreferenceAuto(boolean auto) {
		SharedPreferences pref = getSharedPreferences("LoginInfo", 0);
		SharedPreferences.Editor edit = pref.edit();

		edit.putBoolean("auto", auto);
		edit.commit();
	}

	private Drawable getIcon(int id) {
		return getResources().getDrawable(id);
	}

	View.OnClickListener MenuListener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			switch (v.getId()) { 
			case R.id.search:
				DialogShow();
				break;
			case R.id.board:
				mNav.toggleRightDrawer(); 
				App app = (App) getApplicationContext();
				app.finishToast.cancel();
				app.isFinish = false;
				break;

			}
		}
	};

	private void DialogShow() {
		dialog = new SearchDialogBox(this);
		dialog.getPositiveButton().setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(!dialog.isEmpty()){
					Intent i = new Intent(TabMainActivity.this, BooksListActivity.class);
					i.putExtra("REQUEST", Utils.REQUEST.SEARCH);
					i.putExtra("SearchMessage", dialog.getSearchMessage());
					startActivity(i);					
					dialog.Close();
				} else{
					Toast.makeText(TabMainActivity.this, "�˻�� �Է����ּ���.", Toast.LENGTH_SHORT).show();
				}
			}
		});
		dialog.Show();
	}

	@Override
	public void onTabChanged(String arg0) {
		App app = (App) getApplicationContext();
		app.finishToast.cancel();
		app.isFinish = false;
	}

}
