package org.sec.NanoomMungo.Activity;

import java.io.UnsupportedEncodingException;

import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.parsing.ServerManager;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gcm.GCMRegistrar;

public class GCMManager {

	private static final String TAG = "GCMManager";
	private Context mContext;

	public GCMManager(Context context) {
		mContext = context;
	}

	public void registerGcm() {
		registerGcmTask task1 = new registerGcmTask();
		task1.execute(mContext);
	}

	public class registerGcmTask extends AsyncTask<Context, Integer, String> {

		@Override
		protected String doInBackground(Context... params) {
			// TODO Auto-generated method stub
			String regId;
			do {
				GCMRegistrar.checkDevice(params[0]);
				GCMRegistrar.checkManifest(params[0]);

				regId = GCMRegistrar.getRegistrationId(params[0]);

				if (regId.equals("")) {
					GCMRegistrar.register(params[0], Utils.PROJECT_Number);
				} else {
					Log.e("id", regId);
				}
			} while (regId == "");

			return regId;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);

			registDB task = new registDB();
			task.execute(result);
		}
	}

	public class registDB extends AsyncTask<String, Integer, Void> {

		@Override
		protected Void doInBackground(String... params) {
			// TODO Auto-generated method stub

			try {
				String u_id = java.net.URLEncoder.encode(new String(params[0]
						.getBytes("UTF-8")));
				ServerManager serverManager = new ServerManager();

				StringBuffer sb = new StringBuffer();
				sb.append("user_id=" + Utils.user_id + "&");
				sb.append("reg_id=" + u_id);

				String url = "http://210.118.64.228/esc/gcm/EntryIdsInfo.php";
				serverManager.putJsonData(url, sb);
				Log.i(TAG, "gcm regist success");

			} catch (Exception e) {
				// TODO Auto-generated catch block
				Log.e(TAG, "gcm regist fail");
				e.printStackTrace();
			}

			return null;
		}
	}

	/****************************************
	 * PUSH
	 ****************************************/
	public void pushTask(String userId, String message) {
		try {
			pushGcmTask task = new pushGcmTask();
			task.execute(userId, message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public class pushGcmTask extends AsyncTask<String, Integer, Boolean> {

		@Override
		protected Boolean doInBackground(String... params) {
			// TODO Auto-generated method stub
			String userId = "";
			String message = "";
			try {
				userId = java.net.URLEncoder.encode(new String(params[0].getBytes("UTF-8")));
				message = java.net.URLEncoder.encode(new String(params[1].getBytes("UTF-8")));
			} catch (UnsupportedEncodingException e) { 
				e.printStackTrace();
			}
			
			return pushData(userId, message);
		}

		@Override
		protected void onPostExecute(Boolean result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			
			if(result == false)
				Toast.makeText(mContext, "��û ����", Toast.LENGTH_SHORT).show();
		}
	}

	private boolean pushData(String userId, String message) {
		try {
			ServerManager serverManager = new ServerManager();
			StringBuffer sb = new StringBuffer();
			sb.append("user_id=" + userId + "&");
			sb.append("msg=" + message);

			String url = "http://210.118.64.228/esc/gcm/pushMessage.php";
			serverManager.putJsonData(url, sb);
			Log.i(TAG, "gcm push success");
			return true;
		} catch (Exception e) {
			
			Log.e(TAG, "gcm push fail");
			e.printStackTrace();			
			return false;
		}
	}
}
