package org.sec.NanoomMungo.Activity;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sec.NanoomMungo.Adapter.BooksListViewAdapter;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.detail.BookDetailMoreActivity;
import org.sec.NanoomMungo.parsing.ServerManager;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

/*******
 * 
 *		@author �ɱ⼺
 *		getDistance ���� ���
 *
 **/
public class BooksListActivity extends Activity implements LocationListener {

	private ListView list;
	private ArrayList<BooksRowData> Datalist;
	private BooksListViewAdapter bindingData;
	private ArrayList<Integer> noList;
	private String SearchMessage;
	private DisplayMetrics metrics;
	private TextView emptyMessage;
	
	private int num;
	private int album_num;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_books);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);

		noList = new ArrayList<Integer>();
		Datalist = new ArrayList<BooksRowData>();
		bindingData = new BooksListViewAdapter(this, R.layout.item_tab2book,
				Datalist, metrics);

		emptyMessage = (TextView) findViewById(R.id.empty);
		emptyMessage.setVisibility(View.GONE);
		list = (ListView) findViewById(R.id.list);
		list.setAdapter(bindingData);
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				BooksRowData data = Datalist.get(position);
				Intent i = new Intent(BooksListActivity.this,
						BookDetailMoreActivity.class);
				i.putExtra("name", data.getName());
				i.putExtra("url", data.getUrl());
				i.putExtra("num", num );
				i.putExtra("album_num", album_num);
				startActivity(i);
			}
		});

		Intent i = getIntent();
		Utils.REQUEST type = (Utils.REQUEST) i.getSerializableExtra("REQUEST");
		SearchMessage = i.getStringExtra("SearchMessage");
		if (type == Utils.REQUEST.SEARCH) {
			Log.i("KS", "SearchMessage = " + SearchMessage);
			BookSearchListTask task = new BookSearchListTask();
			task.execute(this);
		} else {
			getNormalInfo();
			bindingData.notifyDataSetChanged();
		}
	}

	public class BookSearchListTask extends AsyncTask<Context, Integer, String> {

		@Override
		protected String doInBackground(Context... params) {
			// TODO Auto-generated method stub
			getSearchInfo();
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			bindingData.notifyDataSetChanged();
		}
	}

	private String getDistance(double lat, double lon) {
		int distance = 0; // ����ڰ� �Ÿ�
		if(Utils.myLocation != null) {

			Location locateSeoul = new Location("Seoul");
			locateSeoul.setLatitude(lat);
			locateSeoul.setLongitude(lon);
			distance = (int)Utils.myLocation.distanceTo(locateSeoul) / 1000; // distanceTo �Լ��� ��ȯ�� m�� km�� ��ȯ

			if (distance == 0) { // 0km�� ��쿡�� m������ ȯ���ؼ� ���
				distance = (int)Utils.myLocation.distanceTo(locateSeoul);
				return String.valueOf(distance + " m");
			}
			else {
				return String.valueOf(distance + " km");
			}
		}
		else	return "0 km";
	}
	
	public void RemoveGet() { // GPS ��� �Ӽ� ����
		Utils.locManager.removeUpdates(this);
	}
	public void onLocationChanged(Location location) {
		Log.d("location", "location changed");
		Utils.myLocation = location;
	}
	public void onProviderDisabled(String s) { 	}
	public void onProviderEnabled(String s) {	}
	public void onStatusChanged(String s, int i, Bundle bundle) {	}
	
	public void getSearchInfo() {

		ServerManager serverManager;
		App app = (App) getApplicationContext();
		serverManager = app.getServerManager();

		String url = Utils.http + "search/search.php";
		StringBuffer sb = new StringBuffer();
		sb.append("where=" + SearchMessage);
		StringBuffer tmp = serverManager.whereJsonData(url, sb);

		try {
			JSONObject jObject = new JSONObject(tmp.toString());
			JSONArray jsonObject = jObject.getJSONArray("regulatory");

			int cnt = jsonObject.length();
			if(cnt == 0) 
				emptyMessage.post(new Runnable() { 
					@Override
					public void run() {
						emptyMessage.setVisibility(View.VISIBLE);
					}
				});
			for (int i = 0; i < cnt; i++) {
				
				JSONObject jtmp = jsonObject.getJSONObject(i);
				noList.add(jtmp.getInt("no"));
				
				String title = jtmp.getString("title");
				String img = jtmp.getString("img");
				double lat = jtmp.getDouble("lat");
				double lon = jtmp.getDouble("lon");
				String distance = getDistance(lat, lon);
				RemoveGet(); // GPS���� �ߴ� �ڵ� ����, ���� ������ ����ؼ� ���Ƿ� ���͸� ��Ƹ��� ���ɼ� ����
				
				num = jtmp.getInt("no");
				album_num = jtmp.getInt("album_no");
				
				/*Log.v("TEST", "å��ȣ= " + jtmp.getInt("no"));
				Log.v("TEST", "����= " + title);
				Log.v("TEST", "��ũ= " + img);
				Log.v("TEST", "����= " + lat);
				Log.v("TEST", "�浵= " + lon);
				Log.v("TEST", "�Ÿ�= " + distance);
				Log.v("TEST", "�۰�= " + jtmp.getString("author"));
				Log.v("TEST", "�з�= " + jtmp.getInt("album_no"));
				Log.v("TEST", "�Ұ�= " + jtmp.getString("content"));*/
				
				Datalist.add(new BooksRowData(title, Utils.uploadImagehttp
						+ img, (String) distance, jtmp.getInt("no"), jtmp.getInt("album_no")));
			
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public void getNormalInfo() {
		Datalist.add(new BooksRowData("�޲ٴ� Ǫ�� �޺��� ��",
				"http://210.118.64.228/image/one.jpg", (String) "�Ÿ���������", 308, 143));
		Datalist.add(new BooksRowData("�θǽ� ����",
				"http://210.118.64.228/image/four.jpg", (String) "�Ÿ���������", 308, 143));
	}
}
