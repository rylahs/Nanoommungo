package org.sec.NanoomMungo.Dialog;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.Utils;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class EditDialogBox implements IDialogBase, IDialogOK_CANCEL {
	private Context context;
	private Dialog dialog;
	private RelativeLayout layout_2;
	private EditText edit;
	
	public EditDialogBox(Context ct) {
		context = ct;

		dialog = new Dialog(context, R.style.CustomDialog);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setCancelable(true);

		dialog.setContentView(R.layout.edit_dialog_box);
		dialog.findViewById(R.id.bt_Negative).setOnClickListener(listener);
		dialog.findViewById(R.id.btn_cancel).setOnClickListener(listener);
		edit = (EditText) dialog.findViewById(R.id.msg);
		 
		setSize();
		setTitle();
	} 
	
	public void setMessage(String message) { 
		edit.setHint(message);
	}
	
	public String getEditStr(){
		return edit.getText().toString();
	}
	
	public void setEditStr(String str){
		edit.setText(str);
	}

	public void setType(){
		edit.setInputType(2);
	}
	

	View.OnClickListener listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			Close();
		}
	};

	private void setTitle() {
		TextView name = (TextView) dialog.findViewById(R.id.tv_title);
		name.setText("������");
	}

	@Override
	public void setTitle(String Title) {
		TextView name = (TextView) dialog.findViewById(R.id.tv_title);
		name.setText(Title);
	}

	@Override
	public View getCancelButton() {
		return (ImageView) dialog.findViewById(R.id.btn_cancel);
	}

	public void OneButtonSetting() {
		dialog.findViewById(R.id.bt_Negative).setVisibility(View.GONE);
	}

	@Override
	public View getPositiveButton() {
		return (ImageView) dialog.findViewById(R.id.bt_Positive);
	}

	@Override
	public View getNegativeButton() {
		return (ImageView) dialog.findViewById(R.id.bt_Negative);
	} 

	@Override
	public void setCancelable(boolean flag) {
		dialog.setCancelable(flag);
	}

	@Override
	public void Show() {
		dialog.show();
	}

	@Override
	public void Close() {
		dialog.dismiss();
	}

	@Override
	public void setSize() {
		layout_2 = (RelativeLayout) dialog.findViewById(R.id.layout_2);
		int width = Utils.getDefaultDisplay(context).getWidth() - 120;
		layout_2.setLayoutParams(new LinearLayout.LayoutParams(width,
				LayoutParams.WRAP_CONTENT));
	}

}
