package org.sec.NanoomMungo.Dialog;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.Utils;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class DialogBox implements IDialogBase, IDialogOK_CANCEL{

	private Context context;
	private Dialog dialog;
	private RelativeLayout layout_2;
	public final static int TWO_TYPE = 0, TWO_TYPE_2 = 5, TWO_TYPE_3 = 6, FOUR_TYPE = 1 , FIND_TYPE = 2, FIVE_TYPE = 3, SIX_TYPE = 4;

	public DialogBox(Context ct) {
		this(ct,TWO_TYPE);
	}
	
	public DialogBox(Context ct, int type) {
		context = ct;

		dialog = new Dialog(context, R.style.CustomDialog);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setCancelable(true);
		
		if(TWO_TYPE == type){
			dialog.setContentView(R.layout.activity_dialog_box2);
			dialog.findViewById(R.id.bt_Negative).setOnClickListener(listener);
		}else if(FIND_TYPE == type){
			dialog.setContentView(R.layout.activity_dialog_box_find);
			dialog.findViewById(R.id.bt_Negative).setOnClickListener(listener);
		}
		else if(TWO_TYPE_2 == type){
			dialog.setContentView(R.layout.activity_dialog_box3);
			dialog.findViewById(R.id.bt_Negative).setOnClickListener(listener);
		}
		else if(TWO_TYPE_3 == type){
			dialog.setContentView(R.layout.activity_dialog_box5);
			dialog.findViewById(R.id.bt_Negative).setOnClickListener(listener);
		}
		else{
			dialog.setContentView(R.layout.activity_dialog_box4);
		}

		setSize();
		setTitle();
	
		dialog.findViewById(R.id.btn_cancel).setOnClickListener(listener);
		dialog.findViewById(R.id.bt_Positive).setOnClickListener(listener);
  
	}

	View.OnClickListener listener = new View.OnClickListener() {

		@Override
		public void onClick(View v) {
			Close();
		}
	};

	private void setTitle() {
		TextView name = (TextView) dialog.findViewById(R.id.tv_title);
		name.setText("������");
	} 
	@Override
	public void setTitle(String Title) {
		TextView name = (TextView) dialog.findViewById(R.id.tv_title);
		name.setText(Title);
	}

	public void setMessage(String message) {
		TextView msg = (TextView) dialog.findViewById(R.id.msg);
		msg.setText(message);
	}
	@Override
	public View getCancelButton() {
		return (ImageView) dialog.findViewById(R.id.btn_cancel);
	}
	
	public void OneButtonSetting() {
		dialog.findViewById(R.id.bt_Negative).setVisibility(View.GONE);
	}

	@Override
	public View getPositiveButton() {
		return  (ImageView) dialog.findViewById(R.id.bt_Positive);
	}
	
	@Override
	public View getNegativeButton() {
		return (ImageView) dialog.findViewById(R.id.bt_Negative);
	}


	@Override
	public void setCancelable(boolean flag) {
		dialog.setCancelable(flag);
	}

	@Override
	public void Show() {
		dialog.show();
	}

	@Override
	public void Close() {
		dialog.dismiss();
	}

	@Override
	public void setSize() {
		layout_2 = (RelativeLayout) dialog.findViewById(R.id.layout_2);
		int width = Utils.getDefaultDisplay(context).getWidth() - 120;
		layout_2.setLayoutParams(new LinearLayout.LayoutParams(width,
				LayoutParams.WRAP_CONTENT));
	}  
}
