package org.sec.NanoomMungo.board;

public class MessageData {

	public String user;
	public String Content;
	public String date;
	public boolean isPhoneNumber;

	public MessageData(String user, String content) {
		this.user = user;
		Content = content;
	}

	public MessageData(String user, String content, String date,
			boolean isPhoneNumber) {
		this.user = user;
		Content = content;
		this.date = date;
		this.isPhoneNumber = isPhoneNumber;
	}

}
