package org.sec.NanoomMungo.board;

import org.json.JSONArray;
import org.json.JSONObject;
import org.sec.NanoomMungo.Activity.App;
import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Dialog.DialogBox;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.parsing.ServerManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.telephony.PhoneNumberUtils;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class AdjDetailActivity extends Activity {
	private final String TAG = "AdjDetailActivity";
	private ImageView[] yesButton = new ImageView[3];
	private ImageView completeButton;
	private Context mContext;

	private ProgressDialog m_ProgressDialog = null;
	private Handler handler = new Handler();
	public final int PROGRESS = 1;

	private EditText et_name, et_id, et_passward, et_phone;
	int no = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_adj_detail);
		mContext = this;
		yesButton[0] = (ImageView) findViewById(R.id.yesButton1);
		yesButton[1] = (ImageView) findViewById(R.id.yesButton2);
		yesButton[2] = (ImageView) findViewById(R.id.yesButton3); 

		et_name = (EditText) findViewById(R.id.name);
		et_id = (EditText) findViewById(R.id.email);
		et_passward = (EditText) findViewById(R.id.passward);
		et_phone = (EditText) findViewById(R.id.phone);

		et_name.setEnabled(false);
		et_id.setEnabled(false);
		et_passward.setEnabled(false);
		et_phone.setEnabled(false);
 
		Intent i = getIntent();
		no = i.getIntExtra("no", -1); 
		Log.i("KS", "no = " + no);
		initData();

		for (ImageView view : yesButton) {
			view.setOnClickListener(yesClickListener);
		}

		completeButton = (ImageView) findViewById(R.id.completeButton);
		completeButton.setOnClickListener(yesClickListener);
	}

	View.OnClickListener yesClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.yesButton1:
				et_name.setEnabled(true);
				et_name.setFocusable(true);
				break;
			case R.id.yesButton2: 
				getPhone();
				break;
			case R.id.yesButton3:
				et_passward.setEnabled(true);
				et_passward.setFocusable(true);
				break; 
			case R.id.completeButton:
				update(); 
				break;
			}
		}
	};

	private void initData(){
		Log.i("KS", "1111");
		Thread thread = new Thread(null, Run_getInfo);
		thread.start();
		showDialog(PROGRESS);
	}
	
	private Runnable Run_getInfo = new Runnable() {
		public void run() {
			Log.i("KS", "2222");
			init();
			handler.post(initResults);
		}
	};

	private Runnable initResults = new Runnable() {
		public void run() {
			m_ProgressDialog.dismiss(); 
		}
	}; 
	
	private void init(){ 
		App app = (App) getApplicationContext();
		ServerManager serverManager = app.getServerManager();

		try {
			String url = Utils.http + "/db/get_join.php";
			StringBuffer sb = new StringBuffer();

			sb.append("no=").append(no);
			StringBuffer tmp = serverManager.whereJsonData(url, sb);
			 
			JSONObject jObject = new JSONObject(tmp.toString());
			JSONArray jsonObject = jObject.getJSONArray("regulatory");
			JSONObject jtmp = jsonObject.getJSONObject(0); 
			
			Log.i("KS", TAG + ", " + jtmp);
			et_name.setText(jtmp.getString("name"));
			et_id.setText(jtmp.getString("user_id"));
			et_passward.setText(jtmp.getString("pwd"));
			et_phone.setText(jtmp.getString("phone_number")); 

		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	private void showDialog() {
		final DialogBox dialogs = new DialogBox(mContext, DialogBox.FOUR_TYPE);
		dialogs.setTitle("�� ���� ����");
		String message = "ȸ�� ������ �����Ͽ����ϴ�.";

		dialogs.setMessage(message);
		dialogs.Show();
		dialogs.getPositiveButton().setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				finish();
				dialogs.Close();
			}
		});
	}

	private void update() {
		Thread thread = new Thread(null, Run_setInfo);
		thread.start();
		showDialog(PROGRESS);
	}

	private Runnable Run_setInfo = new Runnable() {
		public void run() {
			updateData();
			handler.post(updateResults);
		}
	};

	private Runnable updateResults = new Runnable() {
		public void run() {
			m_ProgressDialog.dismiss();
			if(IsAuto()){
				setPreferenceID_PWD(et_id.getText().toString(), et_passward.getText().toString());
			}
			showDialog();
		}
	};

	private void updateData() {
		App app = (App) getApplicationContext();
		ServerManager serverManager = app.getServerManager();

		try {
			String url = Utils.http + "/db/update_join.php";
			StringBuffer sb = new StringBuffer();

			sb.append("user_ID=").append(et_id.getText().toString())
					.append("&");
			sb.append("user_PW=").append(et_passward.getText().toString())
					.append("&");
			sb.append("user_Name=").append(et_name.getText().toString())
					.append("&");
			sb.append("user_Phone=").append(et_phone.getText().toString())
					.append("&");
			sb.append("no=").append(no);
			serverManager.putJsonData(url, sb);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void getPhone() {
		TelephonyManager systemService = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
		String PhoneNumber = systemService.getLine1Number();
		if (PhoneNumber != null) {
			PhoneNumber = PhoneNumber.substring(PhoneNumber.length() - 10,
					PhoneNumber.length());
			PhoneNumber = "0" + PhoneNumber;

			// ������(-) �߰�
			PhoneNumber = PhoneNumberUtils.formatNumber(PhoneNumber);
			et_phone.setText(PhoneNumber);
		} else {
			Toast.makeText(this, "�ش� ����� ��ȣ�� �����ϴ�.", Toast.LENGTH_SHORT)
					.show(); 
		}
	}
	
	public void setPreferenceID_PWD(String _id, String _pwd) {
		SharedPreferences pref = getSharedPreferences("LoginInfo", 0);
		SharedPreferences.Editor edit = pref.edit();

		edit.putString("id", _id);
		edit.putString("pwd", _pwd);
		edit.commit();
	}  
	
	public boolean IsAuto() {
		SharedPreferences pref = getSharedPreferences("LoginInfo", 0);
		return pref.getBoolean("auto", false);
	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case (PROGRESS):
			m_ProgressDialog = new ProgressDialog(this);
			m_ProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			m_ProgressDialog.setMessage("loading..");
			return m_ProgressDialog;
		}
		return null;
	}
}
