package org.sec.NanoomMungo.board;

import java.util.ArrayList;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.parsing.Parsing_announce;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.BaseExpandableListAdapter;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class Notice extends Activity {

	/******** DB - ACTIVITY - LIST CONNECT *********/
	Cursor db_cursor;

	private ExpandableListView listView;

	private ExpandableListAdapter exAdapter;

	private ArrayList<Data_Announce> exList = null;
	LayoutInflater vi;
	Data_Announce[] list;
	/**********************************************/

	// Parsing
	private Parsing_announce poa;

	// Parsing Data
	private String[] announcement_title;
	private String[] announcement_content;
	private String[] announcement_date;
	private String[] tmp_date;

	private int json_cnt;

	private ProgressDialog m_ProgressDialog = null;
	private Handler handler = new Handler();

	public final int PROGRESS = 1;

	Context context;
	ImageView iv_set, iv_talk; // , iv_center;
 

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.announce);

		context = getApplicationContext();
		vi = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);

		setViews();

		try {
			Thread thread = new Thread(null, Run_getInfo);
			thread.start();
			showDialog(PROGRESS);

		}

		catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void setViews() {
		listView = (ExpandableListView) findViewById(R.id.traepe_exListview);
	}

	private Runnable Run_getInfo = new Runnable() {
		public void run() {
			getParsingInfo();
			handler.post(updateResults);
		}
	};

	private Runnable updateResults = new Runnable() {
		public void run() {
			m_ProgressDialog.dismiss();
			getOrders_default();
			setExListView();
		}
	};

	public void setExListView() {
		exAdapter = new MyExpandableListAdapter(this, exList); 
		listView.setAdapter(exAdapter); 
	}

	public void getParsingInfo() {
		poa = new Parsing_announce(Notice.this);
		poa.open();

		json_cnt = poa.getCnt_json();

		if (json_cnt == 0) {
			finish();
			// startActivity(new Intent(context, Internet.class));
		}

		announcement_title = poa.getAnnouncement_title();
		announcement_content = poa.getAnnouncement_content();
		announcement_date = new String[json_cnt];
		tmp_date = poa.getAnnouncement_date();

		for (int i = 0; i < json_cnt; i++) {
			try {
				announcement_date[i] = tmp_date[i].substring(0, 4) + "/"
						+ tmp_date[i].substring(4, 6) + "/"
						+ tmp_date[i].substring(6, 8);
			}

			catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

	private void getOrders_default() {
		int i;
		// Log.e("getOrders_defalut", "getOrders_defalut");
		try {
			exList = new ArrayList<Data_Announce>();
			/*****************************************/
			list = new Data_Announce[json_cnt];
			for (i = 0; i < list.length; i++)
				list[i] = new Data_Announce();
			/***********************************************/
			for (i = 0; i < json_cnt; i++) {
				list[i].setOrderTitle(announcement_title[i]);
				list[i].setOrderContent(announcement_content[i]);
				list[i].setOrderDate(announcement_date[i]);
				exList.add(list[i]);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	class MyExpandableListAdapter extends BaseExpandableListAdapter {
		Context context;
		private ArrayList<Data_Announce> items;

		public MyExpandableListAdapter(Context context,
				ArrayList<Data_Announce> items) {
			super();
			this.context = context;
			this.items = items;
		}

		public long getChildId(int groupPosition, int childPosition) {
			return childPosition;
		}

		public int getChildrenCount(int groupPosition) {
			return 1;
		}

		public long getGroupId(int groupPosition) {
			return groupPosition;
		}

		public View getGroupView(int groupPosition, boolean isExpanded,
				View convertView, ViewGroup parent) {

			Data_Announce title = (Data_Announce) items.get(groupPosition);

			if (convertView == null) {
				LayoutInflater infalInflater = (LayoutInflater) context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = infalInflater.inflate(
						R.layout.announce_row_title, null);
			}

			ImageView iv = (ImageView) convertView.findViewById(R.id.rowicon);
			try {
				if (isExpanded) {
					iv.setImageResource(R.drawable.icon_notice_down);
				} else {
					iv.setImageResource(R.drawable.icon_notice_right);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			TextView tt = (TextView) convertView
					.findViewById(R.id.traepe_setting_title);
			TextView dt = (TextView) convertView
					.findViewById(R.id.traepe_setting_date);
			tt.setText(title.getOrderTitle());
			dt.setText(title.getOrderDate());
			return convertView;
		}

		public View getChildView(int groupPosition, int childPosition,
				boolean isLastChild, View convertView, ViewGroup parent) {

			Data_Announce content = (Data_Announce) items.get(groupPosition);

			if (convertView == null) {
				LayoutInflater infalInflater = (LayoutInflater) context
						.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView = infalInflater.inflate(
						R.layout.announce_row_content, null);
			}

			TextView ct = (TextView) convertView
					.findViewById(R.id.traepe_setting_content);
			ct.setText(content.getOrderContent());

			return convertView;
		}

		public boolean hasStableIds() {
			return true;
		}

		public boolean isChildSelectable(int groupPosition, int childPosition) {
			return true;
		}

		public Object getChild(int groupPosition, int childPosition) {
			return null;
		}

		public Object getGroup(int groupPosition) {
			return null;
		}

		public int getGroupCount() {
			return json_cnt;
		}

	}

	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case (PROGRESS):
			m_ProgressDialog = new ProgressDialog(this);
			m_ProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			m_ProgressDialog.setMessage("loading..");
			return m_ProgressDialog;
		}
		return null;
	}
}