package org.sec.NanoomMungo.board;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.sec.NanoomMungo.Activity.App;
import org.sec.NanoomMungo.Activity.GCMManager;
import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Adapter.MessageAdapter;
import org.sec.NanoomMungo.Dialog.PushDialogBox;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.parsing.ServerManager;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class MessageStorageActivity extends Activity {

	private ListView list;
	private ArrayList<MessageData> Datalist;
	private MessageAdapter messageAdapter; 
	private DisplayMetrics metrics;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_message_storage);

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
 
		Datalist = new ArrayList<MessageData>();
		messageAdapter = new MessageAdapter(this, R.layout.message_row, Datalist, metrics);
 
		list = (ListView) findViewById(R.id.list);
		list.setAdapter(messageAdapter);
		
		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View v, int position,
					long id) { 
				showMessageBox(position);
			}
		});
		
//		MessageListTask task = new MessageListTask();
//		task.execute(this);
		getNormalInfo();
		messageAdapter.notifyDataSetChanged();
	}
	
	public void showMessageBox(final int position){
		final PushDialogBox dialog = new PushDialogBox(MessageStorageActivity.this); 
		dialog.setTitle("�뿩��û");   
		dialog.setRequestId(Utils.user_id);
		dialog.getPositiveButton().setOnClickListener(
				new OnClickListener() {

					@Override
					public void onClick(View v) {
						if(dialog.isCondition()){
							//if(!userId.equals(Utils.user_id)){
							App app = (App) getApplicationContext();
							GCMManager gcmManager = app.getGCMManager();
							gcmManager.pushTask(Datalist.get(position).user, Utils.user_id + "���� ���� �޽���" + "\n ����");
						//} else {
						//	Toast.makeText(mContext, "�ڽſ��� ��û�� �� �����ϴ�.", Toast.LENGTH_SHORT).show();
						//}
							dialog.Close();
						} else {
							Toast.makeText(MessageStorageActivity.this, "����� ��û��¥�� Ȯ�����ּ���.", Toast.LENGTH_SHORT).show();
						} 
					} 
				}); 
		dialog.Show();
	}

	public class MessageListTask extends AsyncTask<Context, Integer, String> {

		@Override
		protected String doInBackground(Context... params) {
			// TODO Auto-generated method stub
			getSearchInfo();
			return null;
		}

		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			super.onPostExecute(result);
			messageAdapter.notifyDataSetChanged();
		}
	} 

	public void getSearchInfo() {

		ServerManager serverManager;
		App app = (App) getApplicationContext();
		serverManager = app.getServerManager();

		String url = Utils.http + "search/search.php";
		StringBuffer sb = new StringBuffer();
		sb.append("where=" + "");
		StringBuffer tmp = serverManager.whereJsonData(url, sb);

		try {
			JSONObject jObject = new JSONObject(tmp.toString());
			JSONArray jsonObject = jObject.getJSONArray("regulatory");

			JSONObject jtmp = jsonObject.getJSONObject(0);

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	public void getNormalInfo() { 
		Datalist.add(new MessageData("user1", "��û1"));
		Datalist.add(new MessageData("user2", "��û2"));
		Datalist.add(new MessageData("user3", "��û3"));
		Datalist.add(new MessageData("user4", "��û4"));
		Datalist.add(new MessageData("user5", "��û5"));
	}
}
