package org.sec.NanoomMungo.board;

import org.json.JSONArray;
import org.json.JSONObject;
import org.sec.NanoomMungo.Activity.App;
import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.parsing.ServerManager;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class AdjustActivity extends Activity {

	private final String TAG = "AdjustActivity";
	private TextView id, pw, wrongValue;
	private ImageView okButton;
	private ProgressDialog m_ProgressDialog = null;
	private Handler handler = new Handler();

	public final int PROGRESS = 1;
	private boolean querySuccess = false;
	private int user_no = -1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_adjust);

		id = (TextView) findViewById(R.id.id);
		pw = (TextView) findViewById(R.id.PW);
		wrongValue = (TextView) findViewById(R.id.wrongValue);
		wrongValue.setVisibility(View.GONE);
		okButton = (ImageView) findViewById(R.id.okButton);

		id.setText(Utils.user_id);
		okButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				okButton.setSelected(true);
				queryCompare(); 
			}
		});
		
		id.setOnClickListener(negativeListener);
		pw.setOnClickListener(negativeListener);
	}
	
	private View.OnClickListener negativeListener = new View.OnClickListener() { 
		@Override
		public void onClick(View v) {
			wrongValue.setVisibility(View.GONE);
		}
	};
	
	private void queryCompare(){
		Thread thread = new Thread(null, Run_getInfo);
		thread.start();
		showDialog(PROGRESS);
	}
	
	private Runnable Run_getInfo = new Runnable() {
		public void run() {
			getState();
			handler.post(updateResults);
		}
	};
	
	private Runnable updateResults = new Runnable() {
		public void run() { 
			m_ProgressDialog.dismiss(); 
			afterProceeding();
		}
	};

	private void getState() {
		App app = (App) getApplicationContext();
		ServerManager serverManager = app.getServerManager();

		try {
			String url = Utils.http + "/db/check_id_pwd.php";
			StringBuffer sb = new StringBuffer();
			sb.append("use_ID=").append(id.getText().toString()).append("&");
			sb.append("use_PW=").append(pw.getText().toString());
			StringBuffer tmp = serverManager.whereJsonData(url, sb);

			JSONObject jObject = new JSONObject(tmp.toString());
			JSONArray jsonObject = jObject.getJSONArray("regulatory");
 
			JSONObject jtmp = jsonObject.getJSONObject(0); 
			int cnt = jtmp.getInt("count"); 
			if (cnt > 0) {
				querySuccess = true;
				user_no = jtmp.getInt("no");
				return;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		querySuccess = false;
	}
	
	private void afterProceeding(){
		if (querySuccess) { 
			wrongValue.setVisibility(View.GONE);
			Intent i = new Intent(AdjustActivity.this, AdjDetailActivity.class);
			i.putExtra("no", user_no);
			startActivity(i); 
			finish();
		} else {
			wrongValue.setText("������ �߸��Ǿ����ϴ�.");
			wrongValue.setVisibility(View.VISIBLE);
		} 
	}
	
	@Override
	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case (PROGRESS):
			m_ProgressDialog = new ProgressDialog(this);
			m_ProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			m_ProgressDialog.setMessage("loading..");
			return m_ProgressDialog;
		}
		return null;
	}
}
