package org.sec.NanoomMungo.Adapter;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.CategoryManager;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.tab2.Category2List;
import org.sec.NanoomMungo.tab2.ImageAdapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ImageView;

public class Category1GridAdapter extends ImageAdapter {
	private LayoutInflater inflater = null;
	private int Width;
	private int Height;
	private Context mContext;

	public Category1GridAdapter(Context context, int[] imageIDs) {
		super(context, imageIDs);
		// TODO Auto-generated constructor stub

		Width = Utils.getDefaultDisplay(context).getWidth();
		Height = Utils.getDefaultDisplay(context).getHeight();
		// inflater = (LayoutInflater) context
		// .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater = LayoutInflater.from(context);
		mContext = context;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		if (convertView == null) {

			convertView = inflater.inflate(R.layout.grid_item, null);
			convertView.setLayoutParams(new GridView.LayoutParams(
					(int) (Width / 4.2), (int) (Width / 3.7)));
		}

		ImageView imageView = (ImageView) convertView
				.findViewById(R.id.imageView1);   
		setImage(imageView, position); 
		
		imageView.setOnClickListener(new OnClickListener() { 
			@Override
			public void onClick(View v) {
				//Category2List.setPosition(position);
				Intent intent = new Intent(mContext, Category2List.class);
				intent.putExtra("category1", getCategory(position)); 
				mContext.startActivity(intent);
			}
		}); 

		return convertView;
	}

	private String getCategory(int position) {
		CategoryManager cm = new CategoryManager(mContext);
		String[] category1 = cm.getCategoryMain();
		return category1[position];
	}

	private void setImage(ImageView imageView, int position) {
		switch (position) {
		case 0:
			imageView.setBackgroundResource(R.drawable.grid_selector1);
			break;
		case 1:
			imageView.setBackgroundResource(R.drawable.grid_selector2);
			break;
		case 2:
			imageView.setBackgroundResource(R.drawable.grid_selector3);
			break;
		case 3:
			imageView.setBackgroundResource(R.drawable.grid_selector4);
			break;
		case 4:
			imageView.setBackgroundResource(R.drawable.grid_selector5);
			break;
		case 5:
			imageView.setBackgroundResource(R.drawable.grid_selector6);
			break;
		}
	}
}
