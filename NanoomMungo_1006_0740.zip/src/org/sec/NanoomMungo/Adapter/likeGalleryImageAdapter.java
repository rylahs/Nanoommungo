package org.sec.NanoomMungo.Adapter;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.ImageDownloader;
import org.sec.NanoomMungo.Utils.ImageDownloader.Mode;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.tab1.likeGalleryData;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.TextView;

public class likeGalleryImageAdapter extends BaseAdapter {
	private Context mContext;
	private int layout;
	private likeGalleryData[] mImageIds;
	private int Width;
	private int Height;
	private ImageDownloader downloader;

	public likeGalleryImageAdapter(Context mContext, int layout,
			likeGalleryData[] mImageIds) {
		this.mContext = mContext;
		this.layout = layout;
		this.mImageIds = mImageIds;

		Width = Utils.getDefaultDisplay(mContext).getWidth();
		Height = Utils.getDefaultDisplay(mContext).getHeight();
		downloader = new ImageDownloader();
		downloader.setMode(Mode.CORRECT);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mImageIds.length;
	}

	@Override
	public likeGalleryData getItem(int position) {
		// TODO Auto-generated method stub
		return mImageIds[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		if (convertView == null) {
			LayoutInflater vi = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(layout, null);

			convertView.setLayoutParams(new Gallery.LayoutParams((int) (Width),
					(int) (Width / 2)));
		}

		ImageView img = (ImageView) convertView.findViewById(R.id.img);
		ImageView img2 = (ImageView) convertView.findViewById(R.id.img2);
		TextView title = (TextView) convertView.findViewById(R.id.txt);
		TextView title2 = (TextView) convertView.findViewById(R.id.txt2);

		// img.setImageResource(getItem(position).getName1());
		// imgF2.setImageResource(getItem(position).getmImageId2());

		try {
			downloader.download(getItem(position).getBmp1(), img);
		} catch (Exception e) {
			img.setImageResource(R.drawable.ic_launcher);
		}

		try {
			downloader.download(getItem(position).getBmp2(), img2);
		} catch (Exception e) {
			img2.setImageResource(R.drawable.ic_launcher);
		}  

		// img.setScaleType(ImageView.ScaleType.FIT_XY);
		// img2.setScaleType(ImageView.ScaleType.FIT_XY);

		title.setText(getItem(position).getShortName1());
		title2.setText(getItem(position).getShortName2());

		return convertView;
	}
}