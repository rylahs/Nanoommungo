package org.sec.NanoomMungo.Adapter;

import java.util.ArrayList;
import java.util.HashMap;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.ImageDownloader;
import org.sec.NanoomMungo.Utils.ImageDownloader.Mode;
import org.sec.NanoomMungo.Utils.Utils;
import org.sec.NanoomMungo.upload.MakeAlbumGridData;
import org.sec.NanoomMungo.upload.MakeAlbumGridData.SELECT;

import android.app.ActionBar.LayoutParams;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

public class MakeAlbumGridImageAdapter extends BaseAdapter {
	private Context mContext;
	private int layout;
	private ArrayList<MakeAlbumGridData> mImageIds; 
	private ImageDownloader downloader;
	private HashMap<Integer, ImageView> mImageMap;
	private int Width;  
	
	public MakeAlbumGridImageAdapter(Context mContext, int layout,
			ArrayList<MakeAlbumGridData> mImageIds) {
		this.mContext = mContext;
		this.layout = layout;
		this.mImageIds = mImageIds;

		mImageMap = new HashMap<Integer, ImageView>();
		Width = Utils.getDefaultDisplay(mContext).getWidth();
		downloader = new ImageDownloader(); 
		downloader.setMode(Mode.CORRECT);
	}   
	public Bitmap ViewToBitmap(int position){
		  
		BitmapDrawable drawable = (BitmapDrawable) mImageMap.get(position).getDrawable();
		Bitmap bmp = drawable.getBitmap();
		
		return bmp;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mImageIds.size();
	}

	@Override
	public MakeAlbumGridData getItem(int position) {
		// TODO Auto-generated method stub
		return mImageIds.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub 
		if (convertView == null) {
			LayoutInflater vi = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(layout, null);			
		}
		
		convertView.setLayoutParams(new GridView.LayoutParams((int) (Width / 4), LayoutParams.WRAP_CONTENT));
		
		mImageMap.put(position, (ImageView) convertView.findViewById(R.id.img));
		TextView title = (TextView) convertView.findViewById(R.id.title);
		
		if (getItem(position).getType() == SELECT.NONE) { 
			mImageMap.get(position).setBackgroundResource(R.drawable.upload_selector);
			mImageMap.get(position).setImageBitmap(null);
			title.setText(""); 
			title.setHint("��    ��");
		} else if (getItem(position).getType() == SELECT.URL) { 
			 
			mImageMap.get(position).setBackgroundResource(android.R.color.transparent);
			downloader.download((String)getItem(position).getImage(), mImageMap.get(position));
			title.setText(getItem(position).getTitle());  
		} else if (getItem(position).getType() == SELECT.BITMAP) { 
			mImageMap.get(position).setBackgroundResource(android.R.color.transparent);
			mImageMap.get(position).setImageBitmap((Bitmap)getItem(position).getImage());
			title.setText(getItem(position).getTitle());
		}  
		
		return convertView;
	}

	public int dpToPixel(int dp) {
		int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
				mContext.getResources().getDisplayMetrics());
		return px;
	}
}