package org.sec.NanoomMungo.Adapter;

import java.util.ArrayList;

import org.sec.NanoomMungo.Activity.BooksRowData;
import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.ImageDownloader;
import org.sec.NanoomMungo.Utils.ImageDownloader.Mode;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class BooksListViewAdapter extends BaseAdapter {

	private LayoutInflater inflater;
	private Context ct;
	private ArrayList<BooksRowData> datalist = null;
	private int layout;
	private ImageDownloader downloader;
	private DisplayMetrics metrics_;

	public BooksListViewAdapter(Context ct, int layout,
			ArrayList<BooksRowData> datalist, DisplayMetrics metrics) {

		inflater = LayoutInflater.from(ct);
		this.ct = ct;
		this.layout = layout;
		this.datalist = datalist;
		downloader = new ImageDownloader();
		downloader.setMode(Mode.CORRECT);
		this.metrics_ = metrics;
	}

	@Override
	public int getCount() {
		return datalist.size();
	}

	@Override
	public BooksRowData getItem(int position) {
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View vi = convertView;

		final Holder holder;
		if (convertView == null) {
			vi = inflater.inflate(layout, null);

			holder = new Holder();
			holder.title = (TextView) vi.findViewById(R.id.bookName);
			holder.bookdetail = (TextView) vi.findViewById(R.id.bookInfo);
			holder.distance = (TextView) vi.findViewById(R.id.bookLength);
			holder.img = (ImageView) vi.findViewById(R.id.bookImage);

			vi.setTag(holder);
		} else {
		    holder = (Holder) convertView.getTag();
		}

//		TextView title = (TextView) vi.findViewById(R.id.bookName);
//		TextView bookdetail = (TextView) vi.findViewById(R.id.bookInfo);
//		TextView distance = (TextView) vi.findViewById(R.id.bookLength);
//		ImageView img = (ImageView) vi.findViewById(R.id.bookImage);
		holder.bookdetail.setVisibility(View.GONE);

		holder.title.setText(getItem(position).getName());
		holder.distance.setText(getItem(position).getDistance());
		//holder.distance.setText(getItem(position).getDistance() + "km");

		try {
			downloader.download(getItem(position).getUrl(), holder.img);
		} catch (Exception e) {
		}

		Animation animation = null;
		animation = new TranslateAnimation(-metrics_.widthPixels, 0, 0, 0);
		animation.setFillAfter(true);
		animation.setInterpolator(AnimationUtils.loadInterpolator(ct, android.R.anim.accelerate_interpolator)); 
		animation.setDuration(getDuration(position));
		vi.startAnimation(animation);
		animation = null;

		return vi;
	}

	private class Holder {
		public TextView title;
		public TextView bookdetail;
		public TextView distance;
		public ImageView img;
	}
	
	private int getDuration(int pos){
		int base = 500;
		return base + ((pos + 1) * 250);//750 * ( pos + 1 ) * ;
	}

}
