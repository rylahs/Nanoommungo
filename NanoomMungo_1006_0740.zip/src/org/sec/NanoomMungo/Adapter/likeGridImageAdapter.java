package org.sec.NanoomMungo.Adapter;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.Utils.ImageDownloader;
import org.sec.NanoomMungo.Utils.ImageDownloader.Mode;
import org.sec.NanoomMungo.tab1.likeGridData;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class likeGridImageAdapter extends BaseAdapter {
	private Context mContext;
	private int layout;
	private likeGridData[] mImageIds;
	private ImageDownloader downloader;

	public likeGridImageAdapter(Context mContext, int layout, likeGridData[] mImageIds) {
		this.mContext = mContext;
		this.layout = layout;
		this.mImageIds = mImageIds;
		
		downloader = new ImageDownloader();
		downloader.setMode(Mode.CORRECT);
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return mImageIds.length;
	}

	@Override
	public likeGridData getItem(int position) {
		// TODO Auto-generated method stub
		return mImageIds[position];
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		if (convertView == null) {
			LayoutInflater vi = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			convertView = vi.inflate(layout, null);
		}

		ImageView img = (ImageView) convertView.findViewById(R.id.img);
		TextView title = (TextView) convertView.findViewById(R.id.txt);
		
		try {
			downloader.download(getItem(position).getBmp(), img);
		} catch (Exception e) {
			img.setImageResource(R.drawable.ic_launcher);
		}
		//img.setImageResource(getItem(position));
		
		img.setScaleType(ImageView.ScaleType.FIT_XY);
		title.setText(getItem(position).getShortName());

		return convertView;
	}
}