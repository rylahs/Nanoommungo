package org.sec.NanoomMungo.Adapter;

import java.util.ArrayList;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.detail.likeDetailRowData;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class DetailListViewAdapter extends BaseAdapter{

	private LayoutInflater inflater;
	private Context ct;
	private ArrayList<likeDetailRowData> datalist = null;
	private int layout;
	
	public DetailListViewAdapter(Context ct, int layout,
			ArrayList<likeDetailRowData> datalist) {
		
		inflater = LayoutInflater.from(ct); 
		this.ct = ct;
		this.layout = layout;
		this.datalist = datalist;
	}

	@Override
	public int getCount() { 
		return datalist.size();
	}

	@Override
	public likeDetailRowData getItem(int position) { 
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) { 
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View vi=convertView;
	    if(convertView==null){ 
	      vi = inflater.inflate(layout, null); 
	    } 
	    
	    TextView name = (TextView) vi.findViewById(R.id.name);
	    TextView addr = (TextView) vi.findViewById(R.id.addr);
	    TextView distance = (TextView) vi.findViewById(R.id.distance);
	    
	    name.setText(getItem(position).getName()+"��");
	    addr.setText(getItem(position).getAddr());
	    distance.setText(getItem(position).getDistance());
	      
		return vi;
	}

}
