package org.sec.NanoomMungo.Adapter;

import java.util.ArrayList;

import org.sec.NanoomMungo.Activity.R;
import org.sec.NanoomMungo.board.MessageData;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MessageAdapter extends BaseAdapter {

	private LayoutInflater inflater;
	private Context ct;
	private ArrayList<MessageData> datalist = null;
	private int layout; 
	private DisplayMetrics metrics_;

	public MessageAdapter(Context ct, int layout,
			ArrayList<MessageData> datalist, DisplayMetrics metrics) {

		inflater = LayoutInflater.from(ct);
		this.ct = ct;
		this.layout = layout;
		this.datalist = datalist; 
		this.metrics_ = metrics;
	}

	@Override
	public int getCount() {
		return datalist.size();
	}

	@Override
	public MessageData getItem(int position) {
		return datalist.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		View vi = convertView;

		final Holder holder;
		if (convertView == null) {
			vi = inflater.inflate(layout, null);

			holder = new Holder();
			holder.user = (TextView) vi.findViewById(R.id.user);
			holder.content = (TextView) vi.findViewById(R.id.content); 

			vi.setTag(holder);
		} else {
		    holder = (Holder) convertView.getTag();
		} 
		
		holder.user.setText(getItem(position).user);
		holder.content.setText(getItem(position).Content);

		 
		Animation animation = null;
		animation = new TranslateAnimation(-metrics_.widthPixels, 0, 0, 0);
		animation.setFillAfter(true);
		animation.setInterpolator(AnimationUtils.loadInterpolator(ct, android.R.anim.accelerate_interpolator)); 
		animation.setDuration(getDuration(position));
		vi.startAnimation(animation);
		animation = null;

		return vi;
	}

	private class Holder {
		public TextView user;
		public TextView content;
	}
	
	private int getDuration(int pos){
		int base = 500;
		return base + ((pos + 1) * 250);//750 * ( pos + 1 ) * ;
	} 
}
